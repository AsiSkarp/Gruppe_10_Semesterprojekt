package com.company;

public class Producer extends User{
    @Override
    public boolean getIsProducer() {
        return true;
    }

    @Override
    public boolean getIsAdmin() {
        return false;
    }

    @Override
    public boolean getIsSuperAdmin() {
        return false;
    }
}
