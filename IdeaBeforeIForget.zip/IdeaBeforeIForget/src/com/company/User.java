package com.company;

import java.util.ArrayList;

public abstract class User {
    private static int productionID = 0001;
    public ArrayList<Production> myList;

    public void addProduction(String name){
        if(getIsProducer() == true) {
            int id = productionID;
            productionID++;

            Production a = new Production(name, id, 0001);
            myList.add(a);

            System.out.println("New production made.");
        } else {
            System.out.println("You can't do that!");
        }
    }

    @Override
    public String toString(){
        String text = "";
        for (Production p: myList) {
            text += "Production name: " + p.getName() + ", Production ID: " + p.getProductionID();
        }
        return text;
    }

    public abstract boolean getIsProducer();

    public abstract boolean getIsAdmin();

    public abstract boolean getIsSuperAdmin();
}
