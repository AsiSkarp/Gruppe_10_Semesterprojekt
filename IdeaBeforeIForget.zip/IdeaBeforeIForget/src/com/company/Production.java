package com.company;

public class Production {
    private String name;
    private int productionID;
    private int producerID;

    public Production(String name, int productionID, int producerID) {
        this.name = name;
        this.productionID = productionID;
        this.producerID = producerID;
    }

    public int getProductionID() {
        return productionID;
    }

    public String getName() {
        return name;
    }

    public void setProductionID(int productionID) {
        this.productionID = productionID;
    }
}
