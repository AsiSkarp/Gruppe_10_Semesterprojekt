package com.company;

public class SuperAdmin extends User{
    @Override
    public boolean getIsProducer() {
        return false;
    }

    @Override
    public boolean getIsAdmin() {
        return false;
    }

    @Override
    public boolean getIsSuperAdmin() {
        return true;
    }
}
