package com.company;

public class Admin extends User{
    @Override
    public boolean getIsProducer() {
        return false;
    }

    @Override
    public boolean getIsAdmin() {
        return true;
    }

    @Override
    public boolean getIsSuperAdmin() {
        return false;
    }
}
