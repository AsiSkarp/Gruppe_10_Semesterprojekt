package com.company;

public class Main {

    public static void main(String[] args) {
	    Admin kaan = new Admin();
	    SuperAdmin ahmad = new SuperAdmin();
	    Producer hamid = new Producer();

        System.out.println("Admin test:");
	    kaan.addProduction("Sharknado");

        System.out.println("\nSuperAdmin test:");
        ahmad.addProduction("Sharknado");

        System.out.println("\nProducer test:");
	    hamid.addProduction("Sharknado");
	    hamid.addProduction("Sharknado 2");

		System.out.println(hamid.toString());

    }
}
